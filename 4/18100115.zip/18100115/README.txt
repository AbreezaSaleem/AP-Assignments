Implemented parts 1 - 4.
Did not implement part 5. 
If one player disconnects, other one wins automatically. 
Valid moves will not be highlighted until both the players are available. 
